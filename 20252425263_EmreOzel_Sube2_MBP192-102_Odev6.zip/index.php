<?php
    require("db.php");

    $sql = "SELECT * FROM ogrenciler";
    $result = mysqli_query($conn, $sql);
    
    if ($result->num_rows > 0) {
        $ogrenciler = [];
        while($row = $result->fetch_assoc()) {
            $okulNo = $row["okul_no"];
            $adSoyad = $row["ad_soyad"];
            $dersAdi = $row["ders_adi"];
            $vize = $row["vize"];
            $odev = $row["odev"];
            $proje = $row["proje"];
            $final = $row["final"];

            $not = $vize * 0.25 + $odev * 0.25 + $proje * 0.05 + $final * 0.45;
            $harfNotu = "";
            $katsayi = "";
            $statu = "";
            
            if ($not <= 49) {
                $harfNotu = "FF";
                $katsayi = "0.00";
                $statu = "Kaldı";
            } elseif ($not <= 59) {
                $harfNotu = "DD";
                $katsayi = "1.00";
                $statu = "Geçer";
            } elseif ($not <= 69) {
                $harfNotu = "DC";
                $katsayi = "1.50";
                $statu = "Geçer";
            } elseif ($not <= 74) {
                $harfNotu = "CC";
                $katsayi = "2.00";
                $statu = "Başarılı";
            } elseif ($not <= 79) {
                $harfNotu = "CB";
                $katsayi = "2.50";
                $statu = "Başarılı";
            } elseif ($not <= 84) {
                $harfNotu = "BB";
                $katsayi = "3.00";
                $statu = "Başarılı";
            } elseif ($not <= 89) {
                $harfNotu = "BA";
                $katsayi = "3.50";
                $statu = "Başarılı";
            } elseif ($not <= 100) {
                $harfNotu = "AA";
                $katsayi = "4.00";
                $statu = "Başarılı";
            }

            $ogrenciler[] = ["Numara" => "$okulNo", "Ad" => "$adSoyad", "Ders" => "$dersAdi", "Vize" => "$vize", "Odev" => "$odev", 
            "Proje" => "$proje", "Final" => "$final", "Not" => "$not", "HarfNotu" => "$harfNotu", "Katsayi" => "$katsayi", "Statu" => "$statu"];
        }
        
    } else { 
        echo "0 results"; 
    }

    mysqli_close($conn);
?>

<html>
<style>
table, th, td {border:1px solid black;}
</style>
    <table>
        <tr>
           <th>Okul No</th>
           <th>Ad Soyad</th>
           <th>Ders Adı</th>
           <th>Vize</th>
           <th>Ödev</th>
           <th>Proje</th>
           <th>Final</th>
           <th>Dönem Sonu Notu</th>
           <th>Harf Notu</th>
           <th>Katsayı</th>
           <th>Statü</th>
        </tr>
        
        <?php for ($i = 0; $i < count($ogrenciler); $i++): ?>
        <?php if ($ogrenciler[$i]["Not"] >= 50): ?>
        <tr style="color:green">
        <?php elseif ($ogrenciler[$i]["Not"] < 50): ?>
        <tr style="color:red">
        <?php endif; ?>
           <th><?php echo($ogrenciler[$i]["Numara"]); ?></th>
           <th><?php echo($ogrenciler[$i]["Ad"]); ?></th>
           <th><?php echo($ogrenciler[$i]["Ders"]); ?></th>
           <th><?php echo($ogrenciler[$i]["Vize"]); ?></th>
           <th><?php echo($ogrenciler[$i]["Odev"]); ?></th>
           <th><?php echo($ogrenciler[$i]["Proje"]); ?></th>
           <th><?php echo($ogrenciler[$i]["Final"]); ?></th>
           <th><?php echo($ogrenciler[$i]["Not"]); ?></th>
           <th><?php echo($ogrenciler[$i]["HarfNotu"]); ?></th>
           <th><?php echo($ogrenciler[$i]["Katsayi"]); ?></th>
           <th><?php echo($ogrenciler[$i]["Statu"]); ?></th>
        </tr>
        <?php endfor; ?>
    </table>
</html>