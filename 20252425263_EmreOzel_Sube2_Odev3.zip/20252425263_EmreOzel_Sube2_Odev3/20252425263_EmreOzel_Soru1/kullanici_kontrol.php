<?php
$users = ["admin"];
$passwords = ["admin" => "1234"];
$safeUsername = htmlspecialchars($_POST["username"]);
$safePassword = htmlspecialchars($_POST["password"]);
if (isset($safeUsername) && isset($safePassword) && $safeUsername != "" && $safePassword != "") {
    if (in_array($safeUsername, $users)) {
        if ($safePassword == $passwords[$safeUsername]) {
            echo "Giriş başarılı, hoş geldiniz admin";
        } else {
            echo "Kullanıcı adı veya şifre hatalı";
        }
    } else {
        echo "Kullanıcı adı veya şifre hatalı";
    }
} else {
    echo "Lütfen tüm alanları doldurun";
}
?>