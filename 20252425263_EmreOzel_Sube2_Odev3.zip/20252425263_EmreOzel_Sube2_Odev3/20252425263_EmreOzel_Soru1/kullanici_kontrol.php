<?php
$users = ["admin"];
$passwords = ["admin" => "1234"];
if (isset($_POST["username"]) && isset($_POST["password"]) && $_POST["username"] != "" && $_POST["password"] != "") {
    if (in_array($_POST["username"], $users)) {
        if ($_POST["password"] == $passwords[$_POST["username"]]) {
            echo "Giriş başarılı, hoş geldiniz admin";
        } else {
            echo "Kullanıcı adı veya şifre hatalı";
        }
    } else {
        echo "Kullanıcı adı veya şifre hatalı";
    }
} else {
    echo "Lütfen tüm alanları doldurun";
}
?>