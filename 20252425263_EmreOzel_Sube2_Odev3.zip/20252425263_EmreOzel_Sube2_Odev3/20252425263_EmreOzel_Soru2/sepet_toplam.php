<?php
if (isset($_POST["urunAdı"]) && isset($_POST["urunFiyatı"]) && isset($_POST["adet"]) &&
isset($_POST["kdv"]) && isset($_POST["indirimKodu"])) {
    $birimFiyat = (float) $_POST["urunFiyatı"];
    $adet = (int) $_POST["adet"];
    $indirimKodu = (int) filter_var($_POST["indirimKodu"], FILTER_SANITIZE_NUMBER_INT);
    

    $araToplam = $birimFiyat * $adet;
    $KDVTutarı = $araToplam * ($_POST["kdv"]/100);
    $indirimTutarı = $araToplam * ($indirimKodu/100);
    $genelToplam = $araToplam + $KDVTutarı - $indirimTutarı;
    $urunAdı = $_POST["urunAdı"];
    
    
    
    echo "$urunAdı için toplam tutar: $genelToplam TL";
    echo "</br>";
    echo "Birim Fiyat: $birimFiyat TL";
    echo "</br>";
    echo "Adet: $adet";
    echo "</br>";
    echo "</br>";
    echo "Ara Toplam: $araToplam TL";
    echo "</br>";
    echo "KDV Tutarı: $KDVTutarı TL";
    echo "</br>";
    if ($_POST["indirimKodu"] != ""){
    echo (('"').$_POST["indirimKodu"].('"')." indirim kodu uygulanmıştır, indirim tutarı: $indirimTutarı TL");
    echo "</br>";
    }
    echo "</br>";
    echo "Genel Toplam: $genelToplam TL";
    
} 
else 
{
    echo "Bir hata oluştu";
}
?>