<?php
$safeUrunAdı = htmlspecialchars($_POST["urunAdı"]);
$safeBirimFiyat = htmlspecialchars($_POST["urunFiyatı"]);
$safeAdet = htmlspecialchars($_POST["adet"]);
$safeKDV = htmlspecialchars($_POST["kdv"]);
$safeIndirimKodu = htmlspecialchars($_POST["indirimKodu"]);

if (isset($safeUrunAdı) && isset($safeBirimFiyat) && isset($safeAdet) &&
isset($safeKDV) && isset($safeIndirimKodu)) {
    $birimFiyat = (float) $safeBirimFiyat;
    $adet = (int) $safeAdet;
    $indirimKodu = (int) filter_var($safeIndirimKodu, FILTER_SANITIZE_NUMBER_INT);
    

    $araToplam = $birimFiyat * $adet;
    $KDVTutarı = $araToplam * ($safeKDV/100);
    $indirimTutarı = $araToplam * ($indirimKodu/100);
    $genelToplam = $araToplam + $KDVTutarı - $indirimTutarı;
    
    
    echo "$safeUrunAdı için toplam tutar: $genelToplam TL";
    echo "</br>";
    echo "Birim Fiyat: $birimFiyat TL";
    echo "</br>";
    echo "Adet: $adet";
    echo "</br>";
    echo "</br>";
    echo "Ara Toplam: $araToplam TL";
    echo "</br>";
    echo "KDV Tutarı: $KDVTutarı TL";
    echo "</br>";
    if ($safeIndirimKodu != ""){
    echo (('"').$safeIndirimKodu.('"')." indirim kodu uygulanmıştır, indirim tutarı: $indirimTutarı TL");
    echo "</br>";
    }
    echo "</br>";
    echo "Genel Toplam: $genelToplam TL";
    
} 
else 
{
    echo "Bir hata oluştu";
}
?>