<?php
    session_start();
    if (isset($_POST["Ad"]) && isset($_POST["Şifre"])) {
        if ($_POST["Ad"] == "admin" && $_POST["Şifre"] == "123"){
            $_SESSION["kullanici"] = "admin";
            header("Location: panel.php");
        } else {
            echo("Hatalı giriş");
        }
    }
?>

<form method="post" action="login.php">
    Ad:
    <input type="text" name="Ad">
    Şifre:
    <input type="text" name="Şifre">
    <button type="submit">Gönder</button>
</form>

