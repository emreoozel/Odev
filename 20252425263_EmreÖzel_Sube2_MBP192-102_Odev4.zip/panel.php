<?php 
    session_start();
    if (session_status() != 2) {   //PHP_SESSION_ACTIVE == 2
        header("Location: login.php");
    } else {
        $kullanici = $_SESSION["kullanici"];
        echo("Hoş geldin, $kullanici");
    }
?>