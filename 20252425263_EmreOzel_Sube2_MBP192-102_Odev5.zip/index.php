<?php

    $ogrencilerContents = file_get_contents("ogrenciler.json");
    $ogrencilerData = json_decode($ogrencilerContents, true);

    $ogrenciNotlar = [];
    for ($i = 0; $i < count($ogrencilerData); $i += 1 ) {
        $okulNo = $ogrencilerData[$i]["okul_no"];
        $vize = $ogrencilerData[$i]["vize"];
        $odev = $ogrencilerData[$i]["odev"];
        $proje = $ogrencilerData[$i]["proje"];
        $final = $ogrencilerData[$i]["final"];
        $not = $vize * 0.25 + $odev * 0.25 + $proje * 0.05 + $final * 0.45;
        $ogrenciNotlar += ["$okulNo" => "$not"];
    }

    $ogrenciHarfNotu = [];
    $ogrenciKatsayi = [];
    $ogrenciStatu = [];
    $ogrenciKayit = "[";
    for ($i = 0; $i < count($ogrencilerData); $i += 1 ) {
        $okulNo = $ogrencilerData[$i]["okul_no"];
        $not = $ogrenciNotlar[$okulNo];
        if ($not <= 49) {
            $ogrenciHarfNotu += ["$okulNo" => "FF"];
            $ogrenciKatsayi += ["$okulNo" => "0.00"];
            $ogrenciStatu += ["$okulNo" => "Kaldı"];
        } elseif ($not <= 59) {
            $ogrenciHarfNotu += ["$okulNo" => "DD"];
            $ogrenciKatsayi += ["$okulNo" => "1.00"];
            $ogrenciStatu += ["$okulNo" => "Geçer"];
        } elseif ($not <= 69) {
            $ogrenciHarfNotu += ["$okulNo" => "DC"];
            $ogrenciKatsayi += ["$okulNo" => "1.50"];
            $ogrenciStatu += ["$okulNo" => "Geçer"];
        } elseif ($not <= 74) {
            $ogrenciHarfNotu += ["$okulNo" => "CC"];
            $ogrenciKatsayi += ["$okulNo" => "2.00"];
            $ogrenciStatu += ["$okulNo" => "Başarılı"];
        } elseif ($not <= 79) {
            $ogrenciHarfNotu += ["$okulNo" => "CB"];
            $ogrenciKatsayi += ["$okulNo" => "2.50"];
            $ogrenciStatu += ["$okulNo" => "Başarılı"];
        } elseif ($not <= 84) {
            $ogrenciHarfNotu += ["$okulNo" => "BB"];
            $ogrenciKatsayi += ["$okulNo" => "3.00"];
            $ogrenciStatu += ["$okulNo" => "Başarılı"];
        } elseif ($not <= 89) {
            $ogrenciHarfNotu += ["$okulNo" => "BA"];
            $ogrenciKatsayi += ["$okulNo" => "3.50"];
            $ogrenciStatu += ["$okulNo" => "Başarılı"];
        } elseif ($not <= 100) {
            $ogrenciHarfNotu += ["$okulNo" => "AA"];
            $ogrenciKatsayi += ["$okulNo" => "4.00"];
            $ogrenciStatu += ["$okulNo" => "Başarılı"];
        } 

        $adSoyad = $ogrencilerData[$i]["ad_soyad"];
        $dersAdi = $ogrencilerData[$i]["ders_adi"];
        $donemSonuNotu = $ogrenciNotlar[$ogrencilerData[$i]["okul_no"]];
        $harfNotu = $ogrenciHarfNotu[$ogrencilerData[$i]["okul_no"]];
        $katsayi = $ogrenciKatsayi[$ogrencilerData[$i]["okul_no"]];
        $statu = $ogrenciStatu[$ogrencilerData[$i]["okul_no"]];
        $ogrenciKayit .= "\n{
\"okul_no\": \"$okulNo\",
\"ad_soyad\": \"$adSoyad\",
\"ders_adi\": \"$dersAdi\",
\"donem_sonu_notu\": $donemSonuNotu,
\"harf_notu\": \"$harfNotu\",
\"katsayi\": $katsayi,
\"statu\": \"$statu\"
}";      
        if ($i < count($ogrencilerData)-1) {
            $ogrenciKayit .= ",";
        }
    }
    $ogrenciKayit .= "\n]";
    file_put_contents("sonuclar.json", $ogrenciKayit)
?>

<html>
<style>
table, th, td {border:1px solid black;}
</style>
    <table>
        <tr>
           <th>Okul No</th>
           <th>Ad Soyad</th>
           <th>Ders Adı</th>
           <th>Vize</th>
           <th>Ödev</th>
           <th>Proje</th>
           <th>Final</th>
           <th>Dönem Sonu Notu</th>
           <th>Harf Notu</th>
           <th>Katsayı</th>
           <th>Statü</th>
        </tr>
        
        <?php for ($i = 0; $i < count($ogrencilerData); $i += 1 ): ?>
        <?php if ($ogrenciNotlar[$ogrencilerData[$i]["okul_no"]] >= 50): ?>
        <tr style="color:green">
        <?php elseif ($ogrenciNotlar[$ogrencilerData[$i]["okul_no"]] < 50): ?>
        <tr style="color:red">
        <?php endif; ?>
           <th><?php echo($ogrencilerData[$i]["okul_no"]); ?></th>
           <th><?php echo($ogrencilerData[$i]["ad_soyad"]); ?></th>
           <th><?php echo($ogrencilerData[$i]["ders_adi"]); ?></th>
           <th><?php echo($ogrencilerData[$i]["vize"]); ?></th>
           <th><?php echo($ogrencilerData[$i]["odev"]); ?></th>
           <th><?php echo($ogrencilerData[$i]["proje"]); ?></th>
           <th><?php echo($ogrencilerData[$i]["final"]); ?></th>
           <th><?php echo($ogrenciNotlar[$ogrencilerData[$i]["okul_no"]]); ?></th>
           <th><?php echo($ogrenciHarfNotu[$ogrencilerData[$i]["okul_no"]]); ?></th>
           <th><?php echo($ogrenciKatsayi[$ogrencilerData[$i]["okul_no"]]); ?></th>
           <th><?php echo($ogrenciStatu[$ogrencilerData[$i]["okul_no"]]); ?></th>
        </tr>
        <?php endfor; ?>
    </table>
</html>